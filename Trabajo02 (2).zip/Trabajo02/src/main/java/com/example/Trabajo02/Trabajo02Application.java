package com.example.Trabajo02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Trabajo02Application {

	public static void main(String[] args) {
		SpringApplication.run(Trabajo02Application.class, args);
	}

}
