package com.example.Trabajo02.entities;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class Auto extends Vehiculo {
    private int cantPuertas;

    public Auto(String marca, String modelo, double precio, int cantPuertas) {
        super(marca, modelo, precio);
        this.cantPuertas = cantPuertas;
    }

    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Puertas: %d // Precio: $%,.2f",
                getMarca(), getModelo(), cantPuertas, getPrecio());
    }
}