package com.example.Trabajo02.entities;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Moto extends Vehiculo {
    private int cilindrada;

    public Moto(String marca, String modelo, double precio, int cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Cilindrada: %dcc // Precio: $%,.2f",
                getMarca(), getModelo(), cilindrada, getPrecio());
    }
}