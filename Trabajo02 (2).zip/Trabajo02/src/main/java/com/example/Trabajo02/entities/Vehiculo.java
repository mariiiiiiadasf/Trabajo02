package com.example.Trabajo02.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public abstract class Vehiculo implements Comparable<Vehiculo> {
    private String marca;
    private String modelo;
    private double precio;

    @Override
    public String toString() {
        return String.format("Marca: %s // Modelo: %s // Precio: $%,.2f", marca, modelo, precio);
    }

    @Override
    public int compareTo(Vehiculo o) {
        int marcaComp = this.marca.compareTo(o.marca);
        if (marcaComp != 0) return marcaComp;

        int modeloComp = this.modelo.compareTo(o.modelo);
        if (modeloComp != 0) return modeloComp;

        return Double.compare(this.precio, o.precio); // ascendente
    }
}