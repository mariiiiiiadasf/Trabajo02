package com.example.Trabajo02.interfaces;

public interface I_File {
    void setText(String text);
    String getText();

    default void info() {
        System.out.println("Interface I_File");
    }
}