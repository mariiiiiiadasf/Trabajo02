package com.example.Trabajo02.test;

import com.example.Trabajo02.entities.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TestApiStreamVehiculo {
    public static void main(String[] args) {
        List<Vehiculo> vehiculos = new ArrayList<>();

        vehiculos.add(new Auto("Peugeot", "206", 200000.00, 4));
        vehiculos.add(new Moto("Honda", "Titan", 60000.00, 125));
        vehiculos.add(new Auto("Peugeot", "208", 250000.00, 5));
        vehiculos.add(new Moto("Yamaha", "YBR", 80500.50, 160));

        // === 1. Vehículo más caro ===
        Vehiculo masCaro = vehiculos.stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .orElse(null);

        // === 2. Vehículo más barato ===
        Vehiculo masBarato = vehiculos.stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .orElse(null);

        // === 3. Vehículo con 'Y' ===
        Vehiculo conY = vehiculos.stream()
                .filter(v -> v.getModelo().contains("Y"))
                .findFirst()
                .orElse(null);

        // === IMPRIMIR RESULTADOS ===
        System.out.println("Vehículo más caro: " + masCaro.getMarca() + " " + masCaro.getModelo());
        System.out.println("Vehículo más barato: " + masBarato.getMarca() + " " + masBarato.getModelo());
        System.out.println("Vehículo que contiene en el modelo la letra 'Y': " +
                conY.getMarca() + " " + conY.getModelo() + " $" + String.format("%,.2f", conY.getPrecio()));

        System.out.println("\n=====================");

        // === 4. POR PRECIO DESCENDENTE: SOLO MARCA Y MODELO ===
        System.out.println("Vehículos ordenados por precio de mayor a menor:");
        vehiculos.stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v -> System.out.println(v.getMarca() + " " + v.getModelo()));

        System.out.println("\n=====================");

        // === 5. ORDEN NATURAL: FORMATO COMPLETO (toString) ===
        System.out.println("Vehículos ordenados por orden natural (marca, modelo, precio):");
        vehiculos.stream()
                .sorted() // Usa compareTo: marca -> modelo -> precio
                .forEach(System.out::println); // Aquí SÍ usa toString() completo
    }
}