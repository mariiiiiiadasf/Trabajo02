package com.example.Trabajo02.utils;

import com.example.Trabajo02.interfaces.I_File;

public class FileBinary implements I_File {
    @Override
    public void setText(String text) {
        System.out.println("Escribiendo Archivo Binario: " + text);
        // Lógica para escribir en un archivo binario
    }

    @Override
    public String getText() {
        // Lógica para leer un archivo binario
        return "Leyendo Archivo Binario";
    }
}