package com.example.Trabajo02.utils;

import com.example.Trabajo02.interfaces.I_File;

public class FileText implements I_File {
    @Override
    public void setText(String text) {
        System.out.println("Escribiendo Archivo de texto: " + text);
        // Lógica para escribir en un archivo de texto
    }

    @Override
    public String getText() {
        // Lógica para leer un archivo de texto
        return "Leyendo Archivo de texto";
    }
}