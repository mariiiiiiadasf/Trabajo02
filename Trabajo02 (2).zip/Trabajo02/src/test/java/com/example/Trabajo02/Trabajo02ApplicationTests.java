package com.example.Trabajo02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabajo02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
